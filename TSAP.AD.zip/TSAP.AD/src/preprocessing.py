"""
TSAP-AD: Leakage-Controlled Pseudo-Chronological Preprocessing
"""
import pandas as pd
import numpy as np

def sanitize_edge_iiotset(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes 21 shortcut identifier columns (IP addresses, MACs, ports, timestamps)
    to prevent shortcut learning and data leakage.
    """
    shortcut_columns = [
        'frame.time', 'ip.src', 'ip.dst', 'tcp.srcport', 'tcp.dstport',
        'udp.srcport', 'udp.dstport', 'arp.src.hw_mac', 'arp.dst.hw_mac',
        'eth.src', 'eth.dst', 'mqtt.clientid', 'mqtt.topic'
    ]
    # Drop columns present in dataframe
    cols_to_drop = [col for col in shortcut_columns if col in df.columns]
    return df.drop(columns=cols_to_drop)

def create_sliding_windows(data: np.ndarray, window_size: int = 10, stride: int = 10):
    """
    Generates non-overlapping sliding windows (S=W=10) from time-series feature streams.
    """
    windows = []
    for i in range(0, len(data) - window_size + 1, stride):
        windows.append(data[i:i + window_size])
    return np.array(windows)