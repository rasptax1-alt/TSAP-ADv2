"""
TSAP-AD: Numba-JIT Accelerated Dynamic Time Warping (DTW) with Sakoe-Chiba Band
"""
import numba
import numpy as np

@numba.jit(nopython=True, fastmath=True)
def dtw_distance_numba(x: np.ndarray, y: np.ndarray, w: int = 2) -> float:
    """
    Computes Sakoe-Chiba band constrained Dynamic Time Warping distance.
    """
    n, m = len(x), len(y)
    w = max(w, abs(n - m))
    dtw_matrix = np.full((n + 1, m + 1), np.inf)
    dtw_matrix[0, 0] = 0.0

    for i in range(1, n + 1):
        for j in range(max(1, i - w), min(m + 1, i + w + 1)):
            cost = abs(x[i - 1] - y[j - 1])
            dtw_matrix[i, j] = cost + min(
                dtw_matrix[i - 1, j],    # insertion
                dtw_matrix[i, j - 1],    # deletion
                dtw_matrix[i - 1, j - 1] # match
            )
    return float(dtw_matrix[n, m])