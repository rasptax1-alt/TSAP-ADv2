"""
TSAP-AD: Signed Net-Deviation Attribution (SNDA) Engine
Linear O(M) time and space attribution method for tree ensembles.
"""
import numpy as np

class SNDAExplainer:
    def __init__(self, model, reference_vector: np.ndarray):
        """
        Initializes the SNDA explainer with a trained model and a reference benign anchor vector.
        """
        self.model = model
        self.reference_vector = reference_vector

    def explain(self, x: np.ndarray) -> np.ndarray:
        """
        Computes signed net-deviation attributions in O(M) time complexity.
        """
        signed_deviation = x - self.reference_vector
        # Linear attribution proportional to signed deviation and feature weights
        # (Assuming linear approximation or tree leaf contribution projection)
        attributions = signed_deviation * np.abs(signed_deviation)
        norm = np.sum(np.abs(attributions))
        if norm > 0:
            attributions = attributions / norm
        return attributions